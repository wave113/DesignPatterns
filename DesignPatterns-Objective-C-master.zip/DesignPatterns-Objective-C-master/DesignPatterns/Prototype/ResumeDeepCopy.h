//
//  ResumeDeepCopy.h
//  DesignPatterns
//
//  Created by leichunfeng on 14/12/20.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "Resume.h"

///  实现深拷贝
@interface ResumeDeepCopy : Resume

@end
