//
//  ResumeShallowCopy.h
//  DesignPatterns
//
//  Created by leichunfeng on 14/12/20.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "Resume.h"

///  实现浅拷贝
@interface ResumeShallowCopy : Resume

@end
