//
//  NationalDebt1.m
//  DesignPatterns
//
//  Created by leichunfeng on 14/12/18.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "NationalDebt1.h"

@implementation NationalDebt1

- (void)buy {
    NSLog(@"国债1买入");
}

- (void)sell {
    NSLog(@"国债1卖出");
}

@end
