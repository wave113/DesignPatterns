//
//  Stock1.m
//  DesignPatterns
//
//  Created by leichunfeng on 14/12/18.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "Stock1.h"

@implementation Stock1

- (void)buy {
    NSLog(@"股票1买入");
}

- (void)sell {
    NSLog(@"股票1卖出");
}

@end
