//
//  Stock2.m
//  DesignPatterns
//
//  Created by leichunfeng on 14/12/18.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "Stock2.h"

@implementation Stock2

- (void)buy {
    NSLog(@"股票2买入");
}

- (void)sell {
    NSLog(@"股票2卖出");
}

@end
