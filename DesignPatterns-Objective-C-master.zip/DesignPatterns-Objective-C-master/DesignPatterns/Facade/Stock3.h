//
//  Stock3.h
//  DesignPatterns
//
//  Created by leichunfeng on 14/12/18.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Stock3 : NSObject

///  买股票
- (void)buy;

///  卖股票
- (void)sell;

@end
