//
//  Realty1.m
//  DesignPatterns
//
//  Created by leichunfeng on 14/12/18.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "Realty1.h"

@implementation Realty1

- (void)buy {
    NSLog(@"房地产1买入");
}

- (void)sell {
    NSLog(@"房地产1卖出");
}

@end
