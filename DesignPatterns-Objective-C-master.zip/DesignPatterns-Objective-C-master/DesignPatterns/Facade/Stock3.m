//
//  Stock3.m
//  DesignPatterns
//
//  Created by leichunfeng on 14/12/18.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "Stock3.h"

@implementation Stock3

- (void)buy {
    NSLog(@"股票3买入");
}

- (void)sell {
    NSLog(@"股票3卖出");
}

@end
