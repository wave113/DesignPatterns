//
//  Realty1.h
//  DesignPatterns
//
//  Created by leichunfeng on 14/12/18.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Realty1 : NSObject

///  买房地产
- (void)buy;

///  卖房地产
- (void)sell;

@end
