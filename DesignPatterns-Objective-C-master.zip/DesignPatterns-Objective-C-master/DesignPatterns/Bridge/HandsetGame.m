//
//  HandsetGame.m
//  DesignPatterns
//
//  Created by leichunfeng on 14/11/2.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "HandsetGame.h"

@implementation HandsetGame

- (void)run {
    NSLog(@"运行手机游戏");
}

@end
