//
//  HandsetBrandM.m
//  DesignPatterns
//
//  Created by leichunfeng on 14/11/2.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "HandsetBrandM.h"

@implementation HandsetBrandM

- (void)run {
    [self.handsetSoft run];
}

@end
