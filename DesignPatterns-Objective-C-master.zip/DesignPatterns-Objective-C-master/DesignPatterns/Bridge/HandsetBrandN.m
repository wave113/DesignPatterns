//
//  HandsetBrandN.m
//  DesignPatterns
//
//  Created by leichunfeng on 14/11/2.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "HandsetBrandN.h"

@implementation HandsetBrandN

- (void)run {
    [self.handsetSoft run];
}

@end
