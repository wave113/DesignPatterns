//
//  TestPaperB.m
//  DesignPatterns
//
//  Created by leichunfeng on 14/11/2.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "TestPaperB.h"

@implementation TestPaperB

- (NSString *)answer1 {
    return @"c";
}

- (NSString *)answer2 {
    return @"a";
}

- (NSString *)answer3 {
    return @"a";
}

@end
