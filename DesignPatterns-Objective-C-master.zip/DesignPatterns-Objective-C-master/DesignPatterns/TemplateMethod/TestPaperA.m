//
//  TestPaperA.m
//  DesignPatterns
//
//  Created by leichunfeng on 14/11/2.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "TestPaperA.h"

@implementation TestPaperA

- (NSString *)answer1 {
    return @"b";
}

- (NSString *)answer2 {
    return @"c";
}

- (NSString *)answer3 {
    return @"a";
}

@end
