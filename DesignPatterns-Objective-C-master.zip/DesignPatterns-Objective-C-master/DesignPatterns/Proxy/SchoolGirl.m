//
//  SchoolGirl.m
//  DesignPatterns
//
//  Created by leichunfeng on 14/12/19.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "SchoolGirl.h"

@implementation SchoolGirl

@end
