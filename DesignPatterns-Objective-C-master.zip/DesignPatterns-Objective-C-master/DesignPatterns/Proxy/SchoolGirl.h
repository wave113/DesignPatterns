//
//  SchoolGirl.h
//  DesignPatterns
//
//  Created by leichunfeng on 14/12/19.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SchoolGirl : NSObject

///  姓名
@property (strong, nonatomic) NSString *name;

@end
