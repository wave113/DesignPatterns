//
//  CashNormal.m
//  DesignPatterns
//
//  Created by leichunfeng on 14-10-19.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "CashNormal.h"

@implementation CashNormal

- (CGFloat)acceptCash:(CGFloat)cash {
    return cash;
}

@end
