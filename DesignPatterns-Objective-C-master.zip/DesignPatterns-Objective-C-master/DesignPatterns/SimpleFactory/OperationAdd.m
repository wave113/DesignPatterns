//
//  OperationAdd.m
//  DesignPatterns
//
//  Created by leichunfeng on 14-10-19.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "OperationAdd.h"

@implementation OperationAdd

- (CGFloat)getResult {
    return self.numberA + self.numberB;
}

@end
