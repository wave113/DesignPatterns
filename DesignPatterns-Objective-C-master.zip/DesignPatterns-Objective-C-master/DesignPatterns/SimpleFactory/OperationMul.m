//
//  OperationMul.m
//  DesignPatterns
//
//  Created by leichunfeng on 14-10-19.
//  Copyright (c) 2014年 zdnst. All rights reserved.
//

#import "OperationMul.h"

@implementation OperationMul

- (CGFloat)getResult {
    return self.numberA * self.numberB;
}

@end
